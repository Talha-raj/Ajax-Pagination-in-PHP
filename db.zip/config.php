<?php 
$con=mysqli_connect("localhost","root","","Employess");
if(!$con){
    header("location:configerror.php");
    exit();
}