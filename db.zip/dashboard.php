<?php
session_start();
if(!isset($_SESSION['userid']))
{
    header("location:login.php");
    exit();
}
?>
<h1>welcome to dashboard
</h1>
<a href="db.php?logout=true">logout</a>