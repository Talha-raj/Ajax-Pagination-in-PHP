<?php 
require_once("config.php");
session_start();
if(isset($_POST["login"]))
{
    $email=strip_tags($_POST["email"]);
    $pass=strip_tags($_POST["pass"]);
$result=mysqli_query($con,"select * from users where email='$email' and password='$pass'");
$row=mysqli_fetch_assoc($result);
    print_r($row);
if($result->num_rows>0)
{
    
    $_SESSION['userid']=$row['email'];
    header("location:dashboard.php");
    exit();
}
else{
    $_SESSION["msg"]="Invalid Username and Password";
   
}
header("location:login.php");
exit();
}
if(isset($_POST["register"]))
{
    $name=strip_tags($_POST["name"]);
    $email=strip_tags($_POST["email"]);
    $pass=strip_tags($_POST["pass"]);
$result=mysqli_query($con,"insert into users(name,email,password) values ('$name','$email','$pass')");

if($result)
{
$_SESSION["msg"]="Your Successfully Register";

}
else{
    $_SESSION["msg"]="Invalid Registration";
   
}
header("location:register.php");
exit();
}
if(isset($_GET['logout']))
{
    session_destroy();
    header("location:login.php");
exit();
}
